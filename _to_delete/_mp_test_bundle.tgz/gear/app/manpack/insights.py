# gear/app/manpack/insights.py
"""Уведомления месяца: новые контрагенты и сотрудники, курсы валют, займы, данные."""
from __future__ import annotations

from datetime import date, timedelta

from . import data
from .config import BANK_LAG_DAYS, FX_ALERT_PCT, FX_CURRENCIES, LOAN_DUE_DAYS
from .theme import fmt_date, money, num, pct


def _safe(fn, default):
    try:
        return fn()
    except Exception:
        return default


def notifications(me: date) -> list[dict]:
    """Список уведомлений: tone (bad / warn / info / good), icon, title, text."""
    start, end = data.month_start(me), me
    out = []

    # --- новые контрагенты и сотрудники (первая операция в ДДС за всю историю)
    def new_parties():
        df = data.cf_first_seen()
        if df.empty:
            return
        g = df.groupby("cp").agg(first=("first", "min"), amount=("amount", "sum"),
                                 salary=("salary", "max")).reset_index()
        new = g[(g["first"] >= start) & (g["first"] <= end) & (g["cp"] != "Без контрагента")]
        staff = new[new["salary"]]
        firms = new[~new["salary"]]
        if len(staff):
            names = ", ".join(staff.sort_values("first")["cp"].head(8))
            out.append({"tone": "info", "icon": "solar:user-plus-linear",
                        "title": f"Новые сотрудники: {len(staff)}",
                        "text": f"Первая выплата по оплате труда в этом месяце: {names}"
                                + ("…" if len(staff) > 8 else "") + "."})
        if len(firms):
            top = firms.reindex(firms["amount"].abs().sort_values(ascending=False).index).head(6)
            names = "; ".join(f"{r.cp} ({money(r.amount)})" for r in top.itertuples())
            out.append({"tone": "info", "icon": "solar:buildings-2-linear",
                        "title": f"Новые контрагенты: {len(firms)}",
                        "text": f"Впервые появились в движении денег: {names}"
                                + ("…" if len(firms) > 6 else "") + "."})
    _safe(new_parties, None)

    # --- курсы валют
    def fx_alerts():
        df = data.fx(start - timedelta(days=5), end)
        if df.empty:
            return
        for cur in FX_CURRENCIES:
            r1, d1 = data.fx_at(df, cur, end)
            r0, _ = data.fx_at(df, cur, start - timedelta(days=1))
            if not r1 or not r0:
                continue
            ch = (r1 - r0) / r0 * 100
            if abs(ch) >= FX_ALERT_PCT:
                word = "вырос" if ch > 0 else "упал"
                out.append({"tone": "warn", "icon": "solar:dollar-minimalistic-linear",
                            "title": f"{cur} {word} на {pct(abs(ch))}",
                            "text": f"Курс {cur}: {num(r0, 4)} → {num(r1, 4)} ₽ за месяц "
                                    f"(на {fmt_date(d1)})."})
    _safe(fx_alerts, None)

    # --- займы с близким сроком погашения
    def loan_alerts():
        df = data.loans(end)
        if df.empty or "repayment_date" not in df:
            return
        today = min(date.today(), end)
        soon = df[df["repayment_date"].notna() & (df["total_debt"].abs() > 1)]
        soon = soon[(soon["repayment_date"].dt.date >= today)
                    & (soon["repayment_date"].dt.date <= today + timedelta(days=LOAN_DUE_DAYS))]
        for r in soon.sort_values("repayment_date").head(5).itertuples():
            side = "нам должны" if r.loan_direction == "issued" else "мы должны"
            out.append({"tone": "warn", "icon": "solar:calendar-mark-linear",
                        "title": f"Срок погашения {fmt_date(r.repayment_date)}",
                        "text": f"{r.counterparty_name}, договор {r.contract_number}: "
                                f"{money(r.total_debt)} ({side})."})
    _safe(loan_alerts, None)

    # --- свежесть банковских данных (только для текущего месяца)
    def lag():
        if end < date.today() - timedelta(days=31):
            return
        _, _, last_bank = data.treasury(min(end, date.today()))
        if last_bank and (date.today() - last_bank).days > BANK_LAG_DAYS:
            out.append({"tone": "warn", "icon": "solar:clock-circle-linear",
                        "title": "Данные банка не обновлялись",
                        "text": f"Движения по счетам загружены по {fmt_date(last_bank)} — "
                                "остатки и ДДС могут быть неполными."})
    _safe(lag, None)

    if not out:
        out.append({"tone": "good", "icon": "solar:check-circle-linear",
                    "title": "Без особых событий",
                    "text": "Новых контрагентов, резких изменений курсов и близких сроков "
                            "погашения в этом месяце нет."})
    return out
