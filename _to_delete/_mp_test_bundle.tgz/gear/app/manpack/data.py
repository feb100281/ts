# gear/app/manpack/data.py
"""Данные дашборда «Управленческий пакет». Только чтение.

P&L, ТБУ и выводы — те же расчёты, что в мэн паке (gear.management.commands.mp).
ДДС — public.cf_to_csv, остатки — запросы листа «Остатки ДС», займы — данные
дашборда «Займы и кредиты», курсы — справочник «Макро».
"""
from __future__ import annotations

import re
import threading
import time
from collections import defaultdict
from datetime import date, timedelta

import pandas as pd
from django.db import connection

from .config import CACHE_TTL, FX_CURRENCIES, SALARY_RE

_cache: dict = {}
_lock = threading.Lock()


def cached(key, fn, ttl=CACHE_TTL):
    with _lock:
        hit = _cache.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    val = fn()
    with _lock:
        if len(_cache) > 64:
            _cache.clear()
        _cache[key] = (time.time(), val)
    return val


def month_end(d: date) -> date:
    nxt = d.replace(day=28) + timedelta(days=4)
    return nxt - timedelta(days=nxt.day)


def month_start(d: date) -> date:
    return d.replace(day=1)


def prev_month_end(d: date) -> date:
    return d.replace(day=1) - timedelta(days=1)


# ------------------------------------------------------------------ P&L
def pl_bundle() -> dict:
    from ..daily_sales.assistant.pl import get_pl
    return get_pl()


def months_list() -> list[date]:
    return pl_bundle()["months"]


def month_summary(me: date) -> dict:
    """Выводы за месяц — тексты и цифры листа «Выводы» мэн пака."""
    from gear.management.commands import mp
    b = pl_bundle()
    months = [m for m in b["months"] if m <= me]
    as_of = min(b["report_date"], me)
    return mp.month_summary(b["pl"], defaultdict(float, b["tax"]), months, as_of, b["conv"])


def derive_period(months: list[date]) -> dict:
    """Показатели за несколько месяцев суммой (как «с начала года» в мэн паке)."""
    from gear.management.commands import mp
    b = pl_bundle()
    agg = defaultdict(float)
    for m in months:
        for k, v in b["base"].get(m, {}).items():
            agg[k] += v or 0.0
    return mp._derive(dict(agg)) if agg else {}


# ------------------------------------------------------------------ ДДС
_BANK_RE = re.compile(r"банк|bank|^ba_|счет|счёт", re.I)


def _cf_columns() -> list[str]:
    def load():
        with connection.cursor() as cur:
            cur.execute("SELECT * FROM public.cf_to_csv LIMIT 0")
            return [c[0] for c in cur.description]
    return cached("cf_cols", load, 3600)


def _bank_names() -> dict:
    """acc_id балансового счёта → название банковского счёта."""
    def load():
        from corporate.models import BankAccount
        out = {}
        for ba in BankAccount.objects.select_related("bank"):
            if ba.bs_acc_id:
                out[ba.bs_acc_id] = str(ba)
        return out
    return cached("bank_names", load, 3600)


def cf_frame(start: date, end: date) -> pd.DataFrame:
    """Операции ДДС за период: d, bank, cp, contract, activity, item, subitem, amount."""
    def load():
        cols = _cf_columns()
        with connection.cursor() as cur:
            cur.execute("SELECT * FROM public.cf_to_csv WHERE date_from::date BETWEEN %s AND %s",
                        [start, end])
            df = pd.DataFrame(cur.fetchall(), columns=cols)
        out = pd.DataFrame(index=df.index)
        out["d"] = pd.to_datetime(df["date_from"]).dt.date if len(df) else []
        out["amount"] = pd.to_numeric(df.get("amount"), errors="coerce").fillna(0.0) if len(df) else []

        def text(col, default):
            if col in df:
                return df[col].fillna("").astype(str).str.strip().replace("", default)
            return default

        out["cp"] = text("cp_name", "Без контрагента")
        out["contract"] = text("contract_name", "Без договора")
        for c in ("activity", "operation", "item", "subitem"):
            out[c] = text(c, "—")
        bank_col = next((c for c in cols if _BANK_RE.search(c)
                         and c not in ("cp_name", "contract_name")), None)
        if bank_col:
            out["bank"] = text(bank_col, "—")
        else:
            acc_col = next((c for c in cols if c in ("acc_id", "bs_acc_id", "ba_acc_id")), None)
            names = _bank_names() if acc_col else {}
            out["bank"] = df[acc_col].map(names).fillna("—") if acc_col and len(df) else "—"
        out["contract_id"] = df["contract_id"] if "contract_id" in df else None
        return out
    return cached(("cf", start, end), load)


def has_bank_dimension() -> bool:
    cols = _cf_columns()
    return any(_BANK_RE.search(c) and c not in ("cp_name", "contract_name") for c in cols) \
        or any(c in ("acc_id", "bs_acc_id", "ba_acc_id") for c in cols)


def cf_months(as_of: date, months: int = 13):
    from ..daily_sales.assistant.treasury import _cf_months
    return cached(("cfm", as_of, months), lambda: _cf_months(as_of, months))


def cf_first_seen() -> pd.DataFrame:
    """Первая дата появления контрагента в ДДС (за всю историю) и признак зарплаты."""
    def load():
        with connection.cursor() as cur:
            cur.execute("""
                SELECT COALESCE(NULLIF(TRIM(cp_name), ''), 'Без контрагента') AS cp,
                       COALESCE(item, '') || ' ' || COALESCE(subitem, '') AS item,
                       MIN(date_from::date) AS first_d, MAX(date_from::date) AS last_d,
                       SUM(amount)::float AS amount, COUNT(*) AS n
                FROM public.cf_to_csv GROUP BY 1, 2
            """)
            df = pd.DataFrame(cur.fetchall(), columns=["cp", "item", "first", "last", "amount", "n"])
        if df.empty:
            return df
        df["salary"] = df["item"].str.contains(SALARY_RE, case=False, regex=True)
        return df
    return cached("cf_first", load)


# ------------------------------------------------------------------ остатки
def treasury(as_of: date):
    from ..daily_sales.assistant.treasury import _treasury
    return cached(("tr", as_of), lambda: _treasury(as_of))


# ------------------------------------------------------------------ займы
def loans(as_of: date) -> pd.DataFrame:
    def load():
        from ..loans.data import get_loans_snapshot
        df = get_loans_snapshot(as_of.isoformat())
        return df if df is not None else pd.DataFrame()
    return cached(("loans", as_of), load)


# ------------------------------------------------------------------ договоры
def contracts(search: str = "", title: str | None = None, only_files: bool = False,
              limit: int = 500) -> list[dict]:
    from django.db.models import Count, Q
    from contracts.models import Contracts

    qs = (Contracts.objects.select_related("title", "owner", "cp")
          .prefetch_related("files")
          .annotate(n_files=Count("files", filter=Q(files__file__isnull=False) & ~Q(files__file="")))
          .order_by("-date"))
    q = (search or "").strip()
    if q:
        qs = qs.filter(Q(cp__name__icontains=q) | Q(number__icontains=q) | Q(cp__tax_id=q))
    if title:
        qs = qs.filter(title__title=title)
    if only_files:
        qs = qs.filter(n_files__gt=0)
    out = []
    for c in qs[:limit]:
        files = [f for f in c.files.all() if f.file]
        out.append({
            "id": c.id,
            "cp": c.cp.name if c.cp_id else "",
            "inn": c.cp.tax_id if c.cp_id else "",
            "type": c.title.title if c.title_id else "",
            "number": c.number or "б/н",
            "date": c.date,
            "owner": c.owner.name if c.owner_id else "",
            "currency": getattr(c, "currency", "") or "",
            "signed": bool(c.is_signed),
            "amendment": c.pid_id is not None,
            "files": [{"url": f.file.url, "name": (f.doc_number or f.get_doc_type_display()
                                                   or "Документ"),
                       "date": f.doc_date} for f in files],
        })
    return out


def contract_titles() -> list[str]:
    def load():
        from contracts.models import ContractsTitle
        return list(ContractsTitle.objects.order_by("title").values_list("title", flat=True))
    return cached("ct_titles", load, 3600)


# ------------------------------------------------------------------ УПД
def upd(start: date, end: date) -> pd.DataFrame:
    """Строки приходов: бухгалтерская и управленческая стоимость без НДС."""
    def load():
        from cards.models import UPDData
        rows = list(UPDData.objects.filter(upd_document__date__range=(start, end)).values(
            "upd_document_id", "upd_document__number", "upd_document__date",
            "upd_document__counterparty__name", "upd_document__contract__number",
            "brand", "upd_qty", "upd_price_vatless", "upd_amount_vatless",
            "man_cost_per_unit"))
        df = pd.DataFrame(rows)
        if df.empty:
            return df
        df = df.rename(columns={
            "upd_document_id": "doc_id", "upd_document__number": "number",
            "upd_document__date": "d", "upd_document__counterparty__name": "cp",
            "upd_document__contract__number": "contract"})
        for c in ("upd_qty", "upd_price_vatless", "upd_amount_vatless", "man_cost_per_unit"):
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
        df["buh"] = df["upd_amount_vatless"].where(
            df["upd_amount_vatless"] != 0, df["upd_qty"] * df["upd_price_vatless"])
        df["man"] = df["upd_qty"] * df["man_cost_per_unit"]
        df["no_man"] = (df["man_cost_per_unit"] == 0)
        df["brand"] = df["brand"].fillna("").replace("", "Без бренда").str.upper()
        df["cp"] = df["cp"].fillna("Без поставщика")
        return df
    return cached(("upd", start, end), load)


# ------------------------------------------------------------------ курсы
def fx(start: date, end: date) -> pd.DataFrame:
    def load():
        from macro.models import CurrencyRate
        rows = list(CurrencyRate.objects.filter(
            base_currency="RUB", currency__in=FX_CURRENCIES,
            date__range=(start - timedelta(days=10), end)).values("date", "currency", "rate"))
        df = pd.DataFrame(rows)
        if df.empty:
            return df
        df["rate"] = pd.to_numeric(df["rate"], errors="coerce")
        return df.sort_values("date")
    return cached(("fx", start, end), load)


def fx_at(df: pd.DataFrame, cur: str, d: date):
    """Курс на дату (последний известный не позже неё)."""
    if df.empty:
        return None, None
    s = df[(df["currency"] == cur) & (df["date"] <= d)]
    if s.empty:
        return None, None
    r = s.iloc[-1]
    return float(r["rate"]), r["date"]


def key_rate(d: date):
    def load():
        from macro.models import KeyRate
        o = KeyRate.objects.filter(date__lte=d).order_by("-date").first()
        return (float(o.key_rate), o.date) if o else (None, None)
    return cached(("kr", d), load, 3600)
