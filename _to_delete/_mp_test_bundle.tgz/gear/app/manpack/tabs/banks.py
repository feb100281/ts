# gear/app/manpack/tabs/banks.py
"""Счета и остатки: банковские счета, депозиты, баланс WB, остатки по месяцам."""
from __future__ import annotations

from collections import defaultdict
from datetime import date

import plotly.graph_objects as go
from dash import html

from .. import data
from ..config import x_btn
from ..theme import (GREEN, MONTHS_SHORT, NEG, POS, card, col, empty, export_button, figure,
                     fmt_date, grid, kpi, money, note, num)


def snapshot(me: date):
    """→ dict: счета, итоги по валютам, депозиты, WB, дата банка, Cash Flow по месяцам."""
    as_of = min(me, date.today())
    rows, deposits, last_bank = data.treasury(as_of)
    banks = [r for r in rows if r[0] == "BANK"]
    wb = next((r for r in rows if r[0] == "WB"), None)
    by_cur = defaultdict(float)
    accounts = []
    for _, name, cur, status, inflow, outflow, bal, *_ in banks:
        if status != "Действующий" and abs(bal or 0) < 0.5:
            continue
        accounts.append({"name": name, "cur": cur, "status": status,
                         "inflow": float(inflow or 0), "outflow": float(outflow or 0),
                         "balance": float(bal or 0)})
        by_cur[cur] += float(bal or 0)
    cm, cf_last = data.cf_months(as_of, 13)
    return {"as_of": as_of, "accounts": accounts, "by_cur": dict(by_cur), "deposits": deposits,
            "wb": wb, "last_bank": last_bank, "cf": cm, "cf_last": cf_last}


def build(me: date):
    s = snapshot(me)
    wb = s["wb"]
    wb_bal = float(wb[6] or 0) if wb else 0.0
    rub = s["by_cur"].get("RUB", 0.0)
    total = rub + s["deposits"] + wb_bal
    fx_cards = [kpi(f"Счета в {c}", num(v, 2) + f" {c}") for c, v in s["by_cur"].items()
                if c != "RUB" and abs(v) > 0.5]

    cm = s["cf"]
    x = [f"{MONTHS_SHORT[m.month - 1]} {str(m.year)[2:]}" for m, *_ in cm]
    fig = go.Figure()
    fig.add_bar(x=x, y=[net for _, _, net, _, _ in cm], name="Сальдо месяца", opacity=0.55,
                marker_color=[POS if net >= 0 else NEG for _, _, net, _, _ in cm],
                hovertemplate="%{y:,.0f} ₽<extra>Сальдо</extra>")
    fig.add_scatter(x=x, y=[cl for *_, cl, _ in cm], name="Остаток на конец месяца",
                    mode="lines+markers", line=dict(color=GREEN, width=2.5),
                    hovertemplate="%{y:,.0f} ₽<extra>Остаток</extra>")

    acc_cols = [col("name", "Банковский счёт", minWidth=320), col("cur", "Валюта", width=95),
                col("status", "Статус", width=130),
                col("inflow", "Поступления (всего)", "num2", width=180),
                col("outflow", "Расход (всего)", "num2", width=170),
                col("balance", "Остаток", "num2", width=170)]
    cf_rows = [{"m": f"{m:%m.%Y}", "op": op, "net": net, "cl": cl} for m, op, net, cl, _ in cm]
    return [
        html.Div(className="mp-kpis", children=[
            kpi("Всего в рублях", money(total), sub="счета RUB + депозиты + баланс WB", tone="pos"),
            kpi("Счета в рублях", money(rub)),
            kpi("Бессрочные депозиты", money(s["deposits"])),
            kpi("Баланс кабинета WB", money(wb_bal),
                sub=(f"в пути {money(wb[7])} · на {fmt_date(wb[9])}" if wb else "нет данных"),
                hint="Деньги в личном кабинете WB — ещё не на расчётном счёте"),
            *fx_cards,
        ]),
        note(f"Остатки на {fmt_date(s['as_of'])}. Движения по банку загружены по "
             f"{fmt_date(s['last_bank'])}, ДДС — по {fmt_date(s['cf_last'])}."),
        card("Банковские счета", grid("mp-acc-grid", s["accounts"], acc_cols,
                                      height=min(420, 90 + 32 * max(len(s["accounts"]), 3))),
             subtitle="закрытые счета с нулевым остатком скрыты",
             actions=export_button(x_btn("banks"), "Остатки, Excel")),
        html.Div(className="mp-grid-2 even", children=[
            card("Остаток денег по месяцам", figure(fig, 300), subtitle="по Cash Flow, ₽"),
            card("Остаток на начало и конец месяца", grid("mp-cfm-grid", cf_rows, [
                col("m", "Месяц", width=110), col("op", "На начало", "num"),
                col("net", "Сальдо", "num"), col("cl", "На конец", "num")], height=300)),
        ]) if cm else empty("Нет данных Cash Flow"),
    ]
