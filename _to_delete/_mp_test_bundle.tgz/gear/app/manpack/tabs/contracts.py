# gear/app/manpack/tabs/contracts.py
"""Договоры: поиск по контрагенту и номеру, открытие прикреплённых файлов."""
from __future__ import annotations

from datetime import date

import dash_mantine_components as dmc
from dash import dcc, html

from .. import data
from ..config import CT_FILES_ID, CT_RESULT_ID, CT_SEARCH_ID, CT_TYPE_ID, x_btn
from ..theme import card, col, empty, export_button, grid, icon, num

POP = {"zIndex": 10020}


def build(me: date):
    return [
        card("Договоры", [
            html.Div(className="mp-filters", children=[
                dmc.TextInput(id=CT_SEARCH_ID, label="Контрагент, номер договора или ИНН",
                              placeholder="Начните вводить…", radius=0, size="sm",
                              debounce=500, className="mp-f grow",
                              leftSection=icon("solar:magnifer-linear", 16)),
                dmc.Select(id=CT_TYPE_ID, label="Тип договора", placeholder="Все типы",
                           data=data.contract_titles(), clearable=True, searchable=True,
                           radius=0, size="sm", comboboxProps=POP, className="mp-f grow"),
                dmc.Switch(id=CT_FILES_ID, label="Только с файлами", checked=False,
                           color="#2F6656", size="sm", className="mp-f switch"),
            ]),
            dcc.Loading(type="dot", color="#2F6656",
                        children=html.Div(id=CT_RESULT_ID, className="mp-result")),
        ], subtitle="нажмите на файл, чтобы открыть договор; карточка — в админке",
            actions=export_button(x_btn("contracts"), "Реестр, Excel")),
    ]


def table(search, title, only_files):
    """→ (колонки, строки) для Excel."""
    items = data.contracts(search or "", title or None, bool(only_files), limit=5000)
    cols = ["Контрагент", "ИНН", "Тип договора", "Номер", "Дата", "Наша компания", "Валюта",
            "Подписан", "Доп. соглашение", "Файлов"]
    rows = [[c["cp"], c["inn"], c["type"], c["number"], c["date"], c["owner"], c["currency"],
             "да" if c["signed"] else "нет", "да" if c["amendment"] else "", len(c["files"])]
            for c in items]
    return cols, rows


def result(search, title, only_files):
    items = data.contracts(search or "", title or None, bool(only_files))
    if not items:
        return empty("Договоры не найдены")
    rows = []
    for c in items:
        files = " · ".join(f"[{f['name']}]({f['url']})" for f in c["files"][:6])
        rows.append({
            "cp": c["cp"], "type": c["type"],
            "number": f"[{c['number']}](/admin/contracts/contracts/{c['id']}/change/)",
            "date": c["date"].strftime("%d.%m.%Y") if c["date"] else "",
            "owner": c["owner"], "cur": c["currency"],
            "signed": "да" if c["signed"] else "нет",
            "kind": "доп. соглашение" if c["amendment"] else "договор",
            "files": files or "—",
        })
    cols = [col("cp", "Контрагент", minWidth=230), col("type", "Тип договора", minWidth=190),
            col("number", "Номер", "link", width=170), col("date", "Дата", width=110),
            col("owner", "Наша компания", minWidth=170), col("cur", "Валюта", width=90),
            col("signed", "Подписан", width=105), col("kind", "Вид", width=140),
            col("files", "Файлы", "link", minWidth=320)]
    with_files = sum(1 for c in items if c["files"])
    return [
        html.Div(f"Найдено договоров: {num(len(items))}, с файлами: {num(with_files)}"
                 + (" · показаны первые 500, уточните поиск" if len(items) >= 500 else ""),
                 className="mp-foot top"),
        grid("mp-ct-grid", rows, cols, height=560),
    ]
