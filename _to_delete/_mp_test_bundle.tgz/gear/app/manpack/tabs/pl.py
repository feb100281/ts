# gear/app/manpack/tabs/pl.py
"""P&L по месяцам года — те же строки и цифры, что в мэн паке."""
from __future__ import annotations

from datetime import date

from dash import html

from .. import data
from ..config import x_btn
from ..theme import MONTHS_SHORT, card, empty, export_button, num

KEY_ROWS = [
    ("rev", "Выручка без НДС", "money", "b"),
    ("cogs", "Себестоимость", "money", ""),
    ("comm", "Комиссия WB", "money", ""),
    ("sell", "Расходы на реализацию (разд. 3)", "money", ""),
    ("promo", "Продвижение WB (разд. 4)", "money", ""),
    ("md", "Маржинальный доход", "money", "b"),
    ("kmd", "КМД, %", "pct", "i"),
    ("other", "Прочие доходы и расходы (разд. 5)", "money", ""),
    ("ovh", "Накладные расходы (разд. 6)", "money", ""),
    ("corp", "Корпоративные расходы (разд. 7)", "money", ""),
    ("fin", "Финансовые расходы (разд. 8)", "money", ""),
    ("fc", "Постоянные затраты (6 + 7 + 8)", "money", "b"),
    ("ebt", "Результат до налога", "money", "b"),
    ("tax", "Налог на прибыль", "money", ""),
    ("net", "Чистая прибыль", "money", "total"),
    ("tbu", "Точка безубыточности", "money", "i"),
    ("zfp_pct", "Запас финансовой прочности, %", "pct", "i"),
    ("tbu_ex", "ТБУ без процентов по конв. займам", "money", "i"),
]
NO_TOTAL_SECTIONS = ("1.", "2.")


def _cell(v, kind):
    if v is None or v != v:
        return html.Td("–", className="num muted")
    cls = "num" + (" neg" if v < 0 else "")
    if kind == "pct":
        return html.Td(f"{v:.1f}".replace(".", ",") + " %", className=cls)
    txt = num(abs(v)) if v >= 0 else f"({num(abs(v))})"
    return html.Td(txt, className=cls)


def table_data(me: date):
    """→ (месяцы, заголовки, ключевые строки, детальные строки) для экрана и Excel."""
    b = data.pl_bundle()
    ms = [m for m in b["months"] if m.year == me.year and m <= me]
    if not ms:
        return [], [], [], []
    ytd = data.derive_period(ms)
    hdr = [MONTHS_SHORT[m.month - 1] for m in ms] + [f"Итого {me.year}"]
    key = []
    for k, label, kind, style in KEY_ROWS:
        vals = [b["derived"][m].get(k) for m in ms] + [ytd.get(k)]
        if k == "conv" and not any(vals):
            continue
        key.append((label, kind, style, vals))

    detail = []
    sections = sorted({s for (m, s, i) in b["pl"] if m in ms})
    for sec in sections:
        items = sorted({i for (m, s, i) in b["pl"] if s == sec and m in ms})
        rows = []
        for it in items:
            vals = [b["pl"].get((m, sec, it)) for m in ms]
            if not any(vals):
                continue
            tot = sum(v or 0 for v in vals)
            is_ratio = "%" in it or sec.strip().startswith("2.")
            rows.append((it, "money", "", vals + [None if is_ratio else tot]))
        if not rows:
            continue
        detail.append((sec.strip(), "head", "", []))
        detail += rows
        if not sec.strip().startswith(NO_TOTAL_SECTIONS):
            tots = [sum((b["pl"].get((m, sec, it)) or 0) for it in items) for m in ms]
            detail.append((f"Итого {sec.strip().split('.')[0]}", "money", "b", tots + [sum(tots)]))
    return ms, hdr, key, detail


def _table(hdr, rows):
    body = []
    for label, kind, style, vals in rows:
        if kind == "head":
            body.append(html.Tr([html.Td(label, colSpan=len(hdr) + 1)], className="sec"))
            continue
        body.append(html.Tr([html.Td(label, className="name")]
                            + [_cell(v, kind) for v in vals], className=style))
    return html.Div(className="mp-table-wrap", children=html.Table(className="mp-table", children=[
        html.Thead(html.Tr([html.Th("Показатель")] + [html.Th(h) for h in hdr])),
        html.Tbody(body),
    ]))


def build(me: date):
    ms, hdr, key, detail = table_data(me)
    if not ms:
        return [empty("За этот год нет данных P&L")]
    return [
        card("Ключевые показатели", _table(hdr, key),
             subtitle=f"{me.year} год, ₽ без НДС · расходы в скобках",
             actions=export_button(x_btn("pl"), "P&L, Excel")),
        card("P&L по статьям", _table(hdr, detail),
             subtitle="разделы и статьи как на листе P&L мэн пака"),
    ]
