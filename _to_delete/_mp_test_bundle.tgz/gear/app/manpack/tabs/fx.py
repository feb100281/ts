# gear/app/manpack/tabs/fx.py
"""Курсы валют: текущий курс и изменение за месяц и с начала года."""
from __future__ import annotations

from datetime import date, timedelta

import plotly.graph_objects as go
from dash import html

from .. import data
from ..config import FX_ALERT_PCT, FX_CURRENCIES, x_btn
from ..theme import (EXPENSE, GREEN, GREEN_2, SLATE, card, empty, export_button, figure,
                     fmt_date, kpi, month_title, note, num, pct)

NAMES = {"USD": "Доллар США", "EUR": "Евро", "CNY": "Китайский юань", "AMD": "Армянский драм"}
COLORS = {"USD": GREEN, "EUR": SLATE, "CNY": EXPENSE, "AMD": GREEN_2}


def stats(me: date):
    """→ [{cur, rate, date, m_ch, y_ch, m0, y0}] и DataFrame за 13 месяцев."""
    end = min(me, date.today())
    start = date(end.year - 1, end.month, 1)
    df = data.fx(start, end)
    out = []
    for cur in FX_CURRENCIES:
        r1, d1 = data.fx_at(df, cur, end)
        if not r1:
            continue
        m0, _ = data.fx_at(df, cur, data.month_start(me) - timedelta(days=1))
        y0, _ = data.fx_at(df, cur, date(me.year, 1, 1) - timedelta(days=1))
        out.append({"cur": cur, "rate": r1, "date": d1, "m0": m0, "y0": y0,
                    "m_ch": (r1 - m0) / m0 * 100 if m0 else None,
                    "y_ch": (r1 - y0) / y0 * 100 if y0 else None})
    return out, df


def build(me: date):
    st, df = stats(me)
    if not st:
        return [empty("В справочнике «Макро» нет курсов USD, EUR, CNY, AMD за этот период")]
    cards = []
    for s in st:
        ch = s["m_ch"]
        tone = "warn" if ch is not None and abs(ch) >= FX_ALERT_PCT else None
        arrow = "" if ch is None else ("▲ " if ch > 0 else "▼ ")
        cards.append(kpi(
            f"{s['cur']} · {NAMES.get(s['cur'], '')}", num(s["rate"], 4) + " ₽",
            sub=f"за месяц {arrow}{pct(ch, 1, sign=True)} · с начала года "
                f"{pct(s['y_ch'], 1, sign=True)}", tone=tone,
            hint=f"Курс на {fmt_date(s['date'])}"))

    fig = go.Figure()
    for s in st:
        d = df[df["currency"] == s["cur"]]
        if d.empty:
            continue
        base = float(d.iloc[0]["rate"]) or 1.0
        fig.add_scatter(x=d["date"], y=d["rate"] / base * 100, name=s["cur"], mode="lines",
                        line=dict(color=COLORS.get(s["cur"], GREEN), width=2),
                        customdata=d["rate"],
                        hovertemplate="%{customdata:.4f} ₽ (%{y:.1f})<extra>" + s["cur"] + "</extra>")
    kr, kr_date = data.key_rate(min(me, date.today()))
    big = [s for s in st if s["m_ch"] is not None and abs(s["m_ch"]) >= FX_ALERT_PCT]
    return [
        html.Div(className="mp-kpis", children=[
            *cards,
            kpi("Ключевая ставка ЦБ", pct(kr, 2) if kr is not None else "—",
                sub=f"действует с {fmt_date(kr_date)}" if kr_date else ""),
        ]),
        note("Резкое изменение за месяц: " + "; ".join(
            f"{s['cur']} {'вырос' if s['m_ch'] > 0 else 'упал'} на {pct(abs(s['m_ch']))}"
            for s in big) + ".", "warn") if big else
        note(f"За {month_title(me).lower()} резких изменений курсов (больше "
             f"{FX_ALERT_PCT:.0f}%) нет."),
        card("Динамика курсов", figure(fig, 340),
             subtitle="индекс: начало периода = 100 · при наведении — курс в рублях",
             actions=export_button(x_btn("fx"), "Курсы, Excel")),
    ]
